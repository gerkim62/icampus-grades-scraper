# iCampus Grades Scraper - Download the grades of everyone in UEAB

<!-- Disclaimer -->

**⚠️ Disclaimer:** This extension serves to show how insecure iCampus is. Do not misuse it for malicious intents. I will share more vulnerabilities soon, so follow me.

## Installation

1. Clone this repo to your machine.
2. Open Google Chrome and go to `chrome://extensions/`.
3. Enable "Developer mode" in the top right corner.
4. Click "Load unpacked" and select the extension folder where you have cloned or stored the files from this repo.

## How to Use

1. After installation, visit the iCampus website and click the button you will see on the bottom right of the screen, named "SCRAPER".

## Files

- `manifest.json`: Extension configuration
- `content.js`: Main functionality
- `styles.css`: Extension styles

## Need Help?

WhatsApp: [254715870654](tel:+254715870654)

---

⭐ If you find this project helpful, please star the repo!
